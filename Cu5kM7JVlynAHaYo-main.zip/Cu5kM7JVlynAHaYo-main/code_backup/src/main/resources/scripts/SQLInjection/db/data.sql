-- USERS
INSERT INTO USERS (name, email) VALUES ('Karan Sasan', 'dummy@xyz.com');
-- Many are there
INSERT INTO USERS (name, email) VALUES ('Jayant Mittal', 'dummy1@xyz.com');
INSERT INTO USERS (name, email) VALUES ('Amit Kumar', 'dummy2@xyz.com');
INSERT INTO USERS (name, email) VALUES ('Nirra Ishq', 'NirraIshq_MyLife@xyz.com');
-- CARS
INSERT INTO CARS (name, image) VALUES ('Audi', '/VulnerableApp/images/cars/Audi.jpg');
INSERT INTO CARS (name, image) VALUES ('BMW', '/VulnerableApp/images/cars/BMW.jpg');
INSERT INTO CARS (name, image) VALUES ('Mercedes-Benz', '/VulnerableApp/images/cars/Mercedes-Benz.jpg');
INSERT INTO CARS (name, image) VALUES ('SKODA', '/VulnerableApp/images/cars/SKODA.jpg');
